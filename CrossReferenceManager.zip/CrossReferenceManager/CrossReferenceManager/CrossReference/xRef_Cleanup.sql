delete from xref_IDXRefData
go
delete from xref_IDXRef
go
delete from xref_MessageArgument
go
delete from xref_MessageDef
go
delete from xref_MessageText
go
delete from xref_ValueXRef
go
delete from xref_ValueXRefData
go
delete from xref_AppInstance
go
delete from xref_AppType
go
