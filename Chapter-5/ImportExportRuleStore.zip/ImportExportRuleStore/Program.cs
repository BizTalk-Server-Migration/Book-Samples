using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.RuleEngine;
using System.IO;

namespace ImportExportRuleStore
{
    class Program
    {
        // server and database to access
        // default is the one that is currently configured on this machine
        static string server = Configuration.DatabaseServer;
        static string database = Configuration.DatabaseName;

        // keep track of the file to import or export
        static string importFileName;
        static string exportFileName;

        // list of strings spoecifying the rulesets/vocabularies to be exported
        static List<string> rulesetsToExport = new List<string>();
        static List<string> vocabulariesToExport = new List<string>();

        static bool addReferencedVocabularies;

        static void DisplayHelp()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("     -import <filename>");
            Console.WriteLine("     -export <filename> [ -rulesets <rulesets> | -vocabulary <vocabularies> ]");
            Console.WriteLine("Additional options:");
            Console.WriteLine("     -server <server>");
            Console.WriteLine("     -database <database>");
            Console.WriteLine("     -addreferencedvocabularies");
            Console.WriteLine();
            Console.WriteLine("<rulesets> are specified as <policyname>:<majorversion>.<minorversion>");
            Console.WriteLine("<vocabularies> are specified as <vocabularyname>:<majorversion>.<minorversion>");
            Console.WriteLine("If version is not specified, all versions of the policy/vocabulary are exported");
            Console.WriteLine();
            Console.WriteLine("Only the first letter of each option is necessary.");
            Console.WriteLine();
            Console.WriteLine("Examples:");
            Console.WriteLine("     ImportExportRuleStore -import sample.xml");
            Console.WriteLine("     ImportExportRuleStore -i sample.xml -s (local) -d BizTalkRuleEngineDb");
            Console.WriteLine("     ImportExportRuleStore -export sample.xml -rulesets Policy1 Policy2:1.0");
            Console.WriteLine("     ImportExportRuleStore -e sample.xml -r Policy1:3.5 -v MyVocabulary:1.0");
        }

        static bool ProcessArguments(string[] args)
        {
            int i = 0;
            while (i < args.Length)
            {
                if (CompareOption(args[i], "-import"))
                {
                    ++i;
                    if (i >= args.Length)
                    {
                        Console.WriteLine("-import must be followed by a file name");
                        DisplayHelp();
                        return false;
                    }
                    importFileName = args[i];
                    ++i;
                    if (!string.IsNullOrEmpty(exportFileName))
                    {
                        Console.WriteLine("Only -import or -export can be specified, not both");
                        DisplayHelp();
                        return false;
                    }
                }
                else if (CompareOption(args[i], "-export"))
                {
                    ++i;
                    if (i >= args.Length)
                    {
                        Console.WriteLine("-export must be followed by a file name");
                        DisplayHelp();
                        return false;
                    }
                    exportFileName = args[i];
                    ++i;
                    if (!string.IsNullOrEmpty(importFileName))
                    {
                        Console.WriteLine("Only -import or -export can be specified, not both");
                        DisplayHelp();
                        return false;
                    }
                }
                else if (CompareOption(args[i], "-server"))
                {
                    ++i;
                    if (i >= args.Length)
                    {
                        Console.WriteLine("-server must be followed by a database server");
                        DisplayHelp();
                        return false;
                    }
                    server = args[i];
                    ++i;
                }
                else if (CompareOption(args[i], "-database"))
                {
                    ++i;
                    if (i >= args.Length)
                    {
                        Console.WriteLine("-database must be followed by a database name");
                        DisplayHelp();
                        return false;
                    }
                    database = args[i];
                    ++i;
                }
                else if (CompareOption(args[i], "-rulesets"))
                {
                    // extract ruleset names
                    ++i;
                    while (i < args.Length)
                    {
                        if (args[i].StartsWith("-", StringComparison.OrdinalIgnoreCase))
                            break;
                        rulesetsToExport.Add(args[i]);
                        ++i;
                    }
                }
                else if (CompareOption(args[i], "-vocabulary") || CompareOption(args[i], "-vocabularies"))
                {
                    // extract vocabulary names
                    ++i;
                    while (i < args.Length)
                    {
                        if (args[i].StartsWith("-", StringComparison.OrdinalIgnoreCase))
                            break;
                        vocabulariesToExport.Add(args[i]);
                        ++i;
                    }
                }
                else if (CompareOption(args[i], "-addReferencedVocabularies"))
                {
                    addReferencedVocabularies = true;
                    ++i;
                }
                else if (CompareOption(args[i], "-help") || CompareOption(args[i], "-?"))
                {
                    DisplayHelp();
                    return false;
                }
                else
                {
                    Console.WriteLine("Unrecognized option \"" + args[i] + "\"");
                    DisplayHelp();
                    return false;
                }
            }
            if ((!string.IsNullOrEmpty(exportFileName)) &&
                    (rulesetsToExport.Count == 0) && (vocabulariesToExport.Count == 0)
                )
            {
                Console.WriteLine("-export requires rulesets or vocabularies to be specified");
                DisplayHelp();
                return false;
            }

            return true;
        }

        static bool CompareOption(string arg, string expected)
        {
            int length = arg.Length;
            if (length > expected.Length)
            {
                // no way it can match
                return false;
            }
            return expected.StartsWith(arg, StringComparison.OrdinalIgnoreCase);
        }

        static SqlRuleStore ConnectToDatabase()
        {
            // check that we can access the database
            StringBuilder location = new StringBuilder();
            location.Append("Data Source=");
            location.Append(server);
            location.Append(";Initial Catalog=");
            location.Append(database);
            location.Append(";Integrated Security=SSPI");   // Windows authentication
            try
            {
                return new SqlRuleStore(location.ToString());
            }
            catch (Exception err)
            {
                Console.WriteLine("Unable to connect to database \"" + database + "\" on server \"" + server + "\"");
                Console.WriteLine("Error: " + err.Message);
            }
            return null;
        }

        static void ImportFile(SqlRuleStore databaseStore, string importFileName)
        {
            // check that the file exists and is a valid RuleStore
            FileInfo fileInfo = new FileInfo(importFileName);
            if (!fileInfo.Exists)
            {
                Console.WriteLine("Unable to locate file \"" + importFileName + "\"");
                return;
            }
            RuleStore fileStore;
            try
            {
                fileStore = new FileRuleStore(importFileName);
            }
            catch (RuleEngineException err)
            {
                Console.WriteLine("Unable to import file \"" + importFileName + "\"");
                Console.WriteLine("Error: " + err.Message);
                return;
            }

            VocabularyInfoCollection vocabularies = fileStore.GetVocabularies(RuleStore.Filter.All);
            VocabularyDictionary vocabulariesToImport = new VocabularyDictionary();
            VocabularyDictionary vocabulariesToImportAndPublish = new VocabularyDictionary();
            RuleSetInfoCollection rulesets = fileStore.GetRuleSets(RuleStore.Filter.All);
            RuleSetDictionary rulesetsToImport = new RuleSetDictionary();

            // check each vocabulary for dependencies
            foreach (VocabularyInfo v in vocabularies)
            {
                Vocabulary vocabulary = fileStore.GetVocabulary(v);
                if ((fileStore.GetDependentRuleSets(v).Count > 0) ||
                    (fileStore.GetDependentVocabularies(v).Count > 0))
                {
                    // vocabulary has dependencies, so it needs to be published
                    vocabulariesToImportAndPublish.Add(vocabulary);
                }
                else
                {
                    // vocabulary has no dependencies, so skip publishing it
                    vocabulariesToImport.Add(vocabulary);
                }
            }

            // load each ruleset
            foreach (RuleSetInfo r in rulesets)
            {
                rulesetsToImport.Add(fileStore.GetRuleSet(r));
            }

            // now try to import everything
            // first check that it can be done
            if (VerifyImport(databaseStore, rulesetsToImport, vocabulariesToImport, vocabulariesToImportAndPublish))
            {
                // no conflicts, so load them in
                try
                {
                    DisplayVersions("Importing ", vocabulariesToImportAndPublish);
                    databaseStore.Save(vocabulariesToImportAndPublish, true);
                    DisplayVersions("Importing ", vocabulariesToImport);
                    databaseStore.Save(vocabulariesToImport, false);
                    DisplayVersions("Importing ", rulesetsToImport);
                    databaseStore.Save(rulesetsToImport);
                }
                catch (RuleEngineException err)
                {
                    Console.WriteLine("Unable to import vocabularies and/or rulesets");
                    Console.WriteLine("Error: " + err.Message);
                }
            }
        }

        static bool VerifyImport(
            SqlRuleStore databaseStore,
            RuleSetDictionary rulesetsToImport,
            VocabularyDictionary vocabulariesToImport,
            VocabularyDictionary vocabulariesToImportAndPublish)
        {
            // loop through the vocabularies, looking to see if any exist
            // already and can't be replaced
            foreach (Vocabulary v1 in vocabulariesToImportAndPublish.Values)
            {
                if (CheckExisting(v1, databaseStore))
                {
                    Console.WriteLine("Unable to import vocabulary \"" + v1.Name +
                        "\", version " + v1.CurrentVersion.MajorRevision + "." + v1.CurrentVersion.MinorRevision +
                        " as the vocabulary already exists in the database");
                    return false;
                }
            }
            foreach (Vocabulary v2 in vocabulariesToImport.Values)
            {
                if (CheckExisting(v2, databaseStore))
                {
                    Console.WriteLine("Unable to import vocabulary \"" + v2.Name +
                        "\", version " + v2.CurrentVersion.MajorRevision + "." + v2.CurrentVersion.MinorRevision +
                        " as the vocabulary already exists in the database");
                    return false;
                }
            }

            // repeat for rulesets
            foreach (RuleSet r1 in rulesetsToImport.Values)
            {
                if (CheckExisting(r1, databaseStore))
                {
                    Console.WriteLine("Unable to import ruleset \"" + r1.Name +
                        "\", version " + r1.CurrentVersion.MajorRevision + "." + r1.CurrentVersion.MinorRevision +
                        " as the ruleset already exists in the database");
                    return false;
                }
            }

            // no conflicts, so we can import
            return true;
        }

        static bool CheckExisting(RuleSet ruleset, SqlRuleStore databaseStore)
        {
            // ideally we could compare the two rulesets and make sure they are the same. 
            // However, right now we simply fail
            RuleSetInfo info = new RuleSetInfo(ruleset.Name,
                ruleset.CurrentVersion.MajorRevision, ruleset.CurrentVersion.MinorRevision);
            return databaseStore.IsRuleSetAccessible(info);
        }

        static bool CheckExisting(Vocabulary vocabulary, SqlRuleStore databaseStore)
        {
            // ideally we could compare the two vocabularies and make sure they are the same. 
            // However, right now we simply fail
            VocabularyInfo info = new VocabularyInfo(vocabulary.Name,
                vocabulary.CurrentVersion.MajorRevision, vocabulary.CurrentVersion.MinorRevision);
            return databaseStore.IsVocabularyAccessible(info);
        }

        static RuleSetDictionary LoadRuleSets(SqlRuleStore databaseStore, List<string> rulesetsToExport)
        {
            // each string can be of the format
            //      name             - load all versions
            //      name:major       - load all versions that match major
            //      name:major.minor - load specific verison
            RuleSetDictionary rulesets = new RuleSetDictionary();
            foreach (string s in rulesetsToExport)
            {
                int versionStartsAt = s.LastIndexOf(':');
                string version = null;
                RuleSetInfoCollection availableVersions;
                if (versionStartsAt > 0)
                {
                    // version specified, strip it off
                    version = s.Substring(versionStartsAt + 1);
                    // get info on all rulesets that match the name part
                    availableVersions = databaseStore.GetRuleSets(s.Substring(0, versionStartsAt), RuleStore.Filter.All);
                }
                else
                {
                    // get info for all rulesets that match the name
                    availableVersions = databaseStore.GetRuleSets(s, RuleStore.Filter.All);
                }
                if (string.IsNullOrEmpty(version))
                {
                    // we want them all
                    foreach (RuleSetInfo info in availableVersions)
                    {
                        if (!rulesets.Contains(info))
                        {
                            rulesets.Add(databaseStore.GetRuleSet(info));
                        }
                    }
                }
                else
                {
                    // version specified, so we need to match
                    int minorStartsAt = version.IndexOf('.');
                    if (minorStartsAt < 0)
                    {
                        // only major version specified
                        int major;
                        if (int.TryParse(version, out major))
                        {
                            // we have a major version (ignore errors)
                            // get each ruleset that matches
                            foreach (RuleSetInfo info in availableVersions)
                            {
                                if (info.MajorRevision == major)
                                {
                                    if (!rulesets.Contains(info))
                                    {
                                        rulesets.Add(databaseStore.GetRuleSet(info));
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // must be major.minor
                        string majorPart = version.Substring(0, minorStartsAt);
                        string minorPart = version.Substring(minorStartsAt + 1);
                        int major, minor;
                        if (int.TryParse(majorPart, out major) && int.TryParse(minorPart, out minor))
                        {
                            // we have a specific version (ignore errors)
                            // get the ruleset that matches (if it exists)
                            foreach (RuleSetInfo info in availableVersions)
                            {
                                if ((info.MajorRevision == major) && (info.MinorRevision == minor))
                                {
                                    if (!rulesets.Contains(info))
                                    {
                                        rulesets.Add(databaseStore.GetRuleSet(info));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return rulesets;
        }

        static VocabularyDictionary LoadVocabularies(SqlRuleStore databaseStore, List<string> vocabulariesToExport)
        {
            // each string can be of the format
            //      name             - load all versions
            //      name:major       - load all versions that match major
            //      name:major.minor - load specific verison
            VocabularyDictionary vocabularies = new VocabularyDictionary();
            foreach (string s in vocabulariesToExport)
            {
                int versionStartsAt = s.LastIndexOf(':');
                string version = null;
                VocabularyInfoCollection availableVersions;
                if (versionStartsAt > 0)
                {
                    // version specified, strip it off
                    version = s.Substring(versionStartsAt + 1);
                    // get info on all vocabularies that match the name part
                    availableVersions = databaseStore.GetVocabularies(s.Substring(0, versionStartsAt), RuleStore.Filter.All);
                }
                else
                {
                    // get info for all vocabularies that match the name
                    availableVersions = databaseStore.GetVocabularies(s, RuleStore.Filter.All);
                }
                if (string.IsNullOrEmpty(version))
                {
                    // we want them all
                    foreach (VocabularyInfo info in availableVersions)
                    {
                        if (!vocabularies.Contains(info))
                        {
                            vocabularies.Add(databaseStore.GetVocabulary(info));
                        }
                    }
                }
                else
                {
                    // version specified, so we need to match
                    int minorStartsAt = version.IndexOf('.');
                    if (minorStartsAt < 0)
                    {
                        // only major version specified
                        int major;
                        if (int.TryParse(version, out major))
                        {
                            // we have a major version (ignore errors)
                            // get each vocabulary that matches
                            foreach (VocabularyInfo info in availableVersions)
                            {
                                if (info.MajorRevision == major)
                                {
                                    if (!vocabularies.Contains(info))
                                    {
                                        vocabularies.Add(databaseStore.GetVocabulary(info));
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // must be major.minor
                        string majorPart = version.Substring(0, minorStartsAt);
                        string minorPart = version.Substring(minorStartsAt + 1);
                        int major, minor;
                        if (int.TryParse(majorPart, out major) && int.TryParse(minorPart, out minor))
                        {
                            // we have a specific version (ignore errors)
                            // get the vocabulary that matches (if it exists)
                            foreach (VocabularyInfo info in availableVersions)
                            {
                                if ((info.MajorRevision == major) && (info.MinorRevision == minor))
                                {
                                    if (!vocabularies.Contains(info))
                                    {
                                        vocabularies.Add(databaseStore.GetVocabulary(info));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return vocabularies;
        }

        static void LoadReferencedVocabularies(SqlRuleStore databaseStore, RuleSetDictionary rulesets, VocabularyDictionary vocabularies)
        {
            // start by going through the items already loaded and get references
            List<VocabularyInfo> referenced = new List<VocabularyInfo>();
            foreach (RuleSet ruleset in rulesets.Values)
            {
                RuleSetInfo ruleSetInfo = new RuleSetInfo(ruleset.Name,
                    ruleset.CurrentVersion.MajorRevision,
                    ruleset.CurrentVersion.MinorRevision);
                VocabularyInfoCollection vocabs = databaseStore.GetReferencedVocabularies(ruleSetInfo);
                foreach (VocabularyInfo info in vocabs)
                {
                    if (!referenced.Contains(info))
                    {
                        referenced.Add(info);
                    }
                }
            }
            foreach (Vocabulary vocabulary in vocabularies.Values)
            {
                VocabularyInfo vocabularyInfo = new VocabularyInfo(vocabulary.Name,
                    vocabulary.CurrentVersion.MajorRevision,
                    vocabulary.CurrentVersion.MinorRevision);
                VocabularyInfoCollection vocabs = databaseStore.GetReferencedVocabularies(vocabularyInfo);
                foreach (VocabularyInfo info in vocabs)
                {
                    if (!referenced.Contains(info))
                    {
                        referenced.Add(info);
                    }
                }
            }
            // now we have a list of referenced vocabularies, process it until done
            // note that we may add to it as we go along
            int i = 0;
            while (i < referenced.Count)
            {
                VocabularyInfo vocabularyInfo = referenced[i];

                // load the vocabulary if we don't have it
                if (!vocabularies.Contains(vocabularyInfo))
                {
                    // check that it is not one of the builtin vocabularies
                    // as they exist in all databases
                    Vocabulary newVocabulary = databaseStore.GetVocabulary(vocabularyInfo);
                    if (!IsBuiltinVocab(newVocabulary))
                    {
                        vocabularies.Add(newVocabulary);
                    }
                }

                // add in any nested dependencies
                VocabularyInfoCollection vocabs = databaseStore.GetReferencedVocabularies(vocabularyInfo);
                foreach (VocabularyInfo info in vocabs)
                {
                    if (!referenced.Contains(info))
                    {
                        referenced.Add(info);
                    }
                }
                // move on to the next entry
                ++i;
            }
        }

        static bool IsBuiltinVocab(Vocabulary v)
        {
            // no easy way to tell what is built-in since they might be localized
            const string PredicatesVocabularyId = "3f0e9bcc-6212-4e6a-853c-e517f157a626";
            const string FunctionsVocabularyId = "aee857f2-09d5-4615-a96c-87041791ec42";
            const string CommonSetsVocabularyId = "5e19cad8-b5f1-4f77-93fd-5210c3e45394";
            const string CommonValuesVocabularyId = "cfded0c3-02bc-4403-ae44-ffdeeb2297d8";
            string vocabId = v.Id;
            return ((string.Compare(vocabId, FunctionsVocabularyId, StringComparison.OrdinalIgnoreCase) == 0) ||
                    (string.Compare(vocabId, PredicatesVocabularyId, StringComparison.OrdinalIgnoreCase) == 0) ||
                    (string.Compare(vocabId, CommonSetsVocabularyId, StringComparison.OrdinalIgnoreCase) == 0) ||
                    (string.Compare(vocabId, CommonValuesVocabularyId, StringComparison.OrdinalIgnoreCase) == 0));
        }

        static void ExportToFile(RuleSetDictionary rulesets, VocabularyDictionary vocabularies, string exportFileName)
        {
            // we don't create exportFileName
            // as a result, you can append to it by using it several times

            RuleStore fileStore;
            try
            {
                fileStore = new FileRuleStore(exportFileName);
            }
            catch (RuleEngineException err)
            {
                Console.WriteLine("Unable to create file \"" + exportFileName + "\"");
                Console.WriteLine("Error: " + err.Message);
                return;
            }
            DisplayVersions("Exporting ", vocabularies);
            DisplayVersions("Exporting ", rulesets);
            fileStore.Save(rulesets, vocabularies, false);
        }

        static void DisplayVersions(string prefix, VocabularyDictionary vocabularies)
        {
            foreach (Vocabulary v in vocabularies.Values)
            {
                Console.WriteLine(prefix + "vocabulary \"" + v.Name + "\", version " +
                    v.CurrentVersion.MajorRevision + "." + v.CurrentVersion.MinorRevision);
            }
        }

        static void DisplayVersions(string prefix, RuleSetDictionary rulesets)
        {
            foreach (RuleSet r in rulesets.Values)
            {
                Console.WriteLine(prefix + "ruleset \"" + r.Name + "\", version " +
                    r.CurrentVersion.MajorRevision + "." + r.CurrentVersion.MinorRevision);
            }
        }

        static void Main(string[] args)
        {
            //look at the arguments passed in
            if (!ProcessArguments(args))
                return;

            // we are happy with the arguments, see if we have access to the database
            SqlRuleStore databaseStore = ConnectToDatabase();
            if (databaseStore == null)
                return;

            if (!string.IsNullOrEmpty(importFileName))
            {
                // user selected import
                ImportFile(databaseStore, importFileName);
            }
            else if (!string.IsNullOrEmpty(exportFileName))
            {
                // user selected export
                // start by converting the strings into a set of rulesets and vocabularies
                RuleSetDictionary rulesets = LoadRuleSets(databaseStore, rulesetsToExport);
                VocabularyDictionary vocabularies = LoadVocabularies(databaseStore, vocabulariesToExport);
                if (addReferencedVocabularies)
                {
                    // add in referenced vocabularies
                    LoadReferencedVocabularies(databaseStore, rulesets, vocabularies);
                }
                if ((rulesets.Count > 0) || (vocabularies.Count > 0))
                {
                    // there is something to export, so do it
                    ExportToFile(rulesets, vocabularies, exportFileName);
                }
                else
                {
                    Console.WriteLine("Specified rulesets or vocabularies are not valid. Please validate that it exists");
                    DisplayHelp();
                }
            }
            else
            {
                // -import or -export not specified, so nothing to do
                DisplayHelp();
            }
        }
    }
}
